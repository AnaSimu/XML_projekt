<?php

$username="";
$password="";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
	
	$ans=$_POST;

	if (empty($ans["username"]))  {
        	echo "Unesite korisničko ime!";
		
    		}
	else if (empty($ans["password"]))  {
        	echo "Unesite lozinku!";
		
    		}
	else {
		$username= $ans["username"];
		$password= $ans["password"];
	
		provjeri($username,$password);
	}
}


function provjeri($username, $password) {
	

	$xml=simplexml_load_file("users.xml");
	
	
	foreach ($xml->user as $user) {
  	 	$usern = $user->username;
		$userpass = $user->password;
		$userime=$user->ime;
		$userprezime=$user->prezime;
		if($usern==$username){
			if($userpass == $password){
				echo "Dobro došli $usrime $usrprezime";
				return;
				}
			else{
				echo "Unešena je neispravna lozinka!";
				return;
				}
			}
		}
		
	echo "Korisnik ne postoji.";
	return;
}
?>

<html>
<head>
<title>Prijavite se</title>

</head>
<body>
<form action="" method="post">

<table>

<tr>
<td>
<label>Korisnički racun :</label>
</td>
<td>
<input id="name" name="username" type="text">
<td>
</tr>


<tr>
<td>
<label>Lozinka :</label>
</td>
<td>
<input id="password" name="password" placeholder="**********" type="password">
<td>
</tr>

<tr>
<td>
<input name="submit" type="submit" value=" Login ">
</td>
<td>

</table>
</form>

</body>
</html>
